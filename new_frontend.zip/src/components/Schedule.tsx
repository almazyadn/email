
import { useEffect, useState } from 'react'
import { getSchedule, updateSchedule } from '../services/api'

export default function Schedule() {
  const [schedule, setSchedule] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  const load = async () => {
    setError(null)
    const res = await getSchedule()
    setSchedule(res.schedule)
  }

  useEffect(()=>{ load() }, [])

  const onSave = async () => {
    setSaving(true); setError(null); setMessage(null)
    try {
      await updateSchedule(schedule)
      setMessage('Schedule updated successfully.')
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to save schedule')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="card">
      <h2 className="text-xl font-semibold mb-4">Schedule</h2>
      {!schedule ? <p>Loading…</p> : (
        <textarea
          className="input h-64 font-mono"
          value={JSON.stringify(schedule, null, 2)}
          onChange={(e)=>setSchedule(JSON.parse(e.target.value || '{}'))}
        />
      )}
      <div className="mt-3 flex gap-2">
        <button className="btn-primary" onClick={onSave} disabled={saving}>{saving?'Saving…':'Save'}</button>
        {error && <span className="text-red-600 text-sm">{error}</span>}
        {message && <span className="text-green-700 text-sm">{message}</span>}
      </div>
    </div>
  )
}
