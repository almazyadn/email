
import { useEffect, useState } from 'react'
import { fetchEmails } from '../services/api'

interface EmailItem {
  subject: string
  sender: string
  datetime_received: string
  preview: string
}

export default function Dashboard() {
  const [emails, setEmails] = useState<EmailItem[]>([])
  const [folder, setFolder] = useState('Inbox')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    setLoading(true); setError(null)
    try {
      const res = await fetchEmails(folder)
      // Expecting backend returns {status, emails:[{subject,sender,datetime_received,preview}]}
      setEmails(res.emails || [])
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to load emails')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [folder])

  return (
    <div className="card">
      <div className="flex items-end gap-2 mb-4">
        <div>
          <label className="block text-sm mb-1">Folder</label>
          <input className="input" value={folder} onChange={e=>setFolder(e.target.value)} placeholder="Inbox" />
        </div>
        <button className="btn-primary" onClick={load} disabled={loading}>Refresh</button>
      </div>
      {error && <p className="text-red-600 text-sm mb-3">{error}</p>}
      {loading ? <p>Loading…</p> : (
        <ul className="divide-y">
          {emails.map((m, i) => (
            <li key={i} className="py-3">
              <div className="flex justify-between">
                <h3 className="font-medium">{m.subject}</h3>
                <span className="text-xs opacity-70">{new Date(m.datetime_received).toLocaleString()}</span>
              </div>
              <p className="text-sm opacity-80">{m.sender}</p>
              <p className="text-sm mt-1 line-clamp-2">{m.preview}</p>
            </li>
          ))}
          {emails.length===0 && <p className="text-sm opacity-70">No emails.</p>}
        </ul>
      )}
    </div>
  )
}
