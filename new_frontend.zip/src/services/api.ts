
import axios from 'axios'

// Use same origin in production; during dev Vite proxies /api to backend:8000
const api = axios.create({
  baseURL: '/',
  headers: { 'Content-Type': 'application/json' }
})

export interface LoginRequest {
  username: string
  password: string
  email: string
  ews_url: string
}

export interface Email {
  subject: string
  sender: string
  datetime_received: string
  preview: string
}

export async function loginApi(payload: LoginRequest) {
  const { data } = await api.post('/api/login', payload)
  return data
}

export async function fetchEmails(folder_name = 'Inbox') {
  const { data } = await api.get('/api/emails', { params: { folder_name } })
  return data
}

export async function getSchedule() {
  const { data } = await api.get('/api/schedule')
  return data
}

export async function updateSchedule(schedule: any) {
  const { data } = await api.post('/api/schedule', { schedule })
  return data
}
